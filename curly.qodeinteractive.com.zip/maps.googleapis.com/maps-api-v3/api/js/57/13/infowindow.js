google.maps.__gjsload__('infowindow', function(_) {
    var AO = function(a) {
            return !!a.infoWindow.get("logAsInternal")
        },
        NPa = function(a, b) {
            if (a.Eg.size === 1) {
                const c = Array.from(a.Eg.values())[0];
                c.mu !== b.mu && (c.set("map", null), a.Eg.delete(c))
            }
            a.Eg.add(b)
        },
        PPa = function(a, b) {
            var c = a.__gm;
            a = c.get("panes");
            c = c.get("innerContainer");
            b = {
                ol: a,
                uj: _.AB.uj(),
                Vv: c,
                shouldFocus: b
            };
            return new OPa(b)
        },
        BO = function(a, b) {
            a.hh.style.visibility = b ? "" : "hidden";
            b && a.shouldFocus && (a.focus(), a.shouldFocus = !1);
            b ? QPa(a) : a.Pg = !1
        },
        RPa = function(a) {
            a.Gi.setAttribute("aria-labelledby", a.Kg.id)
        },
        SPa = function(a) {
            const b = !!a.get("open");
            var c = a.get("content");
            c = b ? c : null;
            if (c == a.Ig) BO(a, b && a.get("position"));
            else {
                if (a.Ig) {
                    const d = a.Ig.parentNode;
                    d == a.Eg && d.removeChild(a.Ig)
                }
                c && (a.Ng = !1, a.Eg.appendChild(c));
                BO(a, b && a.get("position"));
                a.Ig = c;
                CO(a)
            }
        },
        DO = function(a) {
            var b = !!a.get("open"),
                c = a.get("headerContent");
            const d = !!a.get("ariaLabel"),
                e = !a.get("headerDisabled");
            b = b ? c : null;
            a.Gi.style.paddingTop = e ? "0" : "12px";
            b === a.Jg ? a.Gg.style.display = e ? "" : "none" : (a.Jg && (c = a.Jg.parentNode, c === a.Kg && c.removeChild(a.Jg)),
                b && (a.Ng = !1, a.Kg.appendChild(b), e && !d && RPa(a)), a.Gg.style.display = e ? "" : "none", a.Jg = b, CO(a))
        },
        CO = function(a) {
            var b = a.getSize();
            if (b) {
                var c = b.Ol;
                b = b.minWidth;
                a.Gi.style.maxWidth = _.St(c.width);
                a.Gi.style.maxHeight = _.St(c.height);
                a.Gi.style.minWidth = _.St(b);
                a.Eg.style.maxHeight = _.Nn.Eg ? _.St(c.height - 18) : _.St(c.height - 36);
                EO(a);
                a.Mg.start()
            }
        },
        TPa = function(a) {
            const b = a.get("pixelOffset") || new _.em(0, 0);
            var c = new _.em(a.Gi.offsetWidth, a.Gi.offsetHeight);
            a = -b.height + c.height + 11 + 60;
            let d = b.height + 60;
            const e = -b.width + c.width / 2 + 60;
            c = b.width + c.width / 2 + 60;
            b.height < 0 && (d -= b.height);
            return {
                top: a,
                bottom: d,
                left: e,
                right: c
            }
        },
        QPa = function(a) {
            !a.Pg && a.get("open") && a.get("visible") && a.get("position") && (_.Rk(a, "visible"), a.Pg = !0)
        },
        EO = function(a) {
            var b = a.get("position");
            if (b && a.get("pixelOffset")) {
                var c = TPa(a);
                const d = b.x - c.left,
                    e = b.y - c.top,
                    f = b.x + c.right;
                c = b.y + c.bottom;
                _.ou(a.anchor, b);
                b = a.get("zIndex");
                _.qu(a.hh, _.tj(b) ? b : e + 60);
                a.set("pixelBounds", _.Ym(d, e, f, c))
            }
        },
        VPa = function(a, b, c) {
            return b instanceof _.fl ? new UPa(a,
                b, c) : new UPa(a, b)
        },
        XPa = function(a) {
            a.Eg && a.ii.push(_.Ok(a.Eg, "pixelposition_changed", () => {
                WPa(a)
            }))
        },
        WPa = function(a) {
            const b = a.model.get("pixelPosition") || a.Eg && a.Eg.get("pixelPosition");
            a.Ig.set("position", b)
        },
        ZPa = function(a) {
            a = a.__gm;
            a.get("IW_AUTO_CLOSER") || a.set("IW_AUTO_CLOSER", new YPa);
            return a.get("IW_AUTO_CLOSER")
        },
        YPa = class {
            constructor() {
                this.Eg = new Set
            }
        };
    var OPa = class extends _.$k {
        constructor(a) {
            super();
            this.Ig = this.Jg = this.Og = null;
            this.Pg = this.Ng = !1;
            this.Vv = a.Vv;
            this.shouldFocus = a.shouldFocus;
            this.hh = document.createElement("div");
            this.hh.style.cursor = "default";
            this.hh.style.position = "absolute";
            this.hh.style.left = this.hh.style.top = "0";
            a.ol.floatPane.appendChild(this.hh);
            this.anchor = _.pu("div", this.hh);
            this.Lg = _.pu("div", this.anchor);
            this.Gi = _.pu("div", this.Lg);
            this.Gi.setAttribute("role", "dialog");
            this.Gi.tabIndex = -1;
            this.Gg = _.pu("div", this.Gi);
            this.Kg =
                _.pu("div", this.Gg);
            this.Sg = _.pu("div", this.Lg);
            this.Eg = _.pu("div", this.Gi);
            _.zGa(this.hh);
            _.ju(this.Gi, "gm-style-iw");
            _.ju(this.anchor, "gm-style-iw-a");
            _.ju(this.Lg, "gm-style-iw-t");
            _.ju(this.Sg, "gm-style-iw-tc");
            _.ju(this.Gi, "gm-style-iw-c");
            _.ju(this.Gg, "gm-style-iw-chr");
            _.ju(this.Kg, "gm-style-iw-ch");
            _.ju(this.Eg, "gm-style-iw-d");
            this.Kg.setAttribute("id", _.Ho());
            _.Nn.Eg && !_.Nn.Lg && (this.Gi.style.paddingInlineEnd = "0", this.Gi.style.paddingBottom = "0", this.Eg.style.overflow = "scroll");
            BO(this, !1);
            _.Kk(this.hh, "mousedown", _.Bk);
            _.Kk(this.hh, "mouseup", _.Bk);
            _.Kk(this.hh, "mousemove", _.Bk);
            _.Kk(this.hh, "pointerdown", _.Bk);
            _.Kk(this.hh, "pointerup", _.Bk);
            _.Kk(this.hh, "pointermove", _.Bk);
            _.Kk(this.hh, "dblclick", _.Bk);
            _.Kk(this.hh, "click", _.Bk);
            _.Kk(this.hh, "touchstart", _.Bk);
            _.Kk(this.hh, "touchend", _.Bk);
            _.Kk(this.hh, "touchmove", _.Bk);
            _.Vt(this.hh, "contextmenu", this, this.Rg);
            _.Vt(this.hh, "wheel", this, _.Bk);
            _.Vt(this.hh, "mousewheel", this, _.yk);
            _.Vt(this.hh, "MozMousePixelScroll", this, _.yk);
            this.Fg =
                new _.eB({
                    Tp: new _.cm(12, 12),
                    fr: new _.em(24, 24),
                    offset: new _.cm(-6, -6),
                    Rz: !0,
                    ownerElement: this.Gg
                });
            this.Gg.appendChild(this.Fg.element);
            _.Kk(this.Fg.element, "click", b => {
                _.Bk(b);
                _.Rk(this, "closeclick");
                this.set("open", !1)
            });
            this.Mg = new _.tn(() => {
                !this.Ng && this.get("content") && this.get("visible") && (_.Rk(this, "domready"), this.Ng = !0)
            }, 0);
            this.Qg = _.Kk(this.hh, "keydown", b => {
                b.key !== "Escape" && b.key !== "Esc" || !this.Gi.contains(document.activeElement) || (b.stopPropagation(), _.Rk(this, "closeclick"), this.set("open", !1))
            })
        }
        ariaLabel_changed() {
            const a = this.get("ariaLabel");
            a ? this.Gi.setAttribute("aria-label", a) : (this.Gi.removeAttribute("aria-label"), this.get("headerDisabled") || RPa(this))
        }
        open_changed() {
            SPa(this);
            DO(this)
        }
        headerContent_changed() {
            DO(this)
        }
        headerDisabled_changed() {
            DO(this)
        }
        content_changed() {
            SPa(this)
        }
        pendingFocus_changed() {
            this.get("pendingFocus") && (this.get("open") && this.get("visible") && this.get("position") ? _.Un(this.Gi, !0) : console.warn("Setting focus on InfoWindow was ignored. This is most likely due to InfoWindow not being visible yet."),
                this.set("pendingFocus", !1))
        }
        dispose() {
            setTimeout(() => {
                document.activeElement && document.activeElement !== document.body || (this.Og && this.Og !== document.body ? _.Un(this.Og, !0) || _.Un(this.Vv, !0) : _.Un(this.Vv, !0))
            });
            this.Qg && _.Fk(this.Qg);
            this.hh.parentNode.removeChild(this.hh);
            this.Mg.stop();
            this.Mg.dispose()
        }
        getSize() {
            var a = this.get("layoutPixelBounds"),
                b = this.get("pixelOffset");
            const c = this.get("maxWidth") || 648,
                d = this.get("minWidth") || 0;
            if (!b) return null;
            a ? (b = a.maxY - a.minY - (11 + -b.height), a = a.maxX - a.minX -
                6, a >= 240 && (a -= 120), b >= 240 && (b -= 120)) : (a = 648, b = 654);
            a = Math.min(a, c);
            a = Math.max(d, a);
            a = Math.max(0, a);
            b = Math.max(0, b);
            return {
                Ol: new _.em(a, b),
                minWidth: d
            }
        }
        pixelOffset_changed() {
            const a = this.get("pixelOffset") || new _.em(0, 0);
            this.Lg.style.right = _.St(-a.width);
            this.Lg.style.bottom = _.St(-a.height + 11);
            CO(this)
        }
        layoutPixelBounds_changed() {
            CO(this)
        }
        position_changed() {
            this.get("position") ? (EO(this), BO(this, !!this.get("open"))) : BO(this, !1)
        }
        zIndex_changed() {
            EO(this)
        }
        visible_changed() {
            this.hh.style.display = this.get("visible") ?
                "" : "none";
            this.Mg.start();
            if (this.get("visible")) {
                const a = this.Fg.element.style.display;
                this.Fg.element.style.display = "none";
                this.Fg.element.getBoundingClientRect();
                this.Fg.element.style.display = a;
                QPa(this)
            } else this.Pg = !1
        }
        Rg(a) {
            let b = !1;
            const c = this.get("content");
            let d = a.target;
            for (; !b && d;) b = d == c, d = d.parentNode;
            b ? _.yk(a) : _.Ak(a)
        }
        focus() {
            this.Og = document.activeElement;
            let a;
            _.Nn.Mg && (a = this.Eg.getBoundingClientRect());
            if (this.get("disableAutoPan")) _.Un(this.Gi, !0);
            else {
                var b = _.vu(this.Eg);
                if (b.length) {
                    b =
                        b[0];
                    a = a || this.Eg.getBoundingClientRect();
                    var c = b.getBoundingClientRect();
                    _.Un(c.bottom <= a.bottom && c.right <= a.right ? b : this.Gi, !0)
                } else _.Un(this.Fg.element, !0)
            }
        }
    };
    var UPa = class {
        constructor(a, b, c) {
            this.model = a;
            this.isOpen = !0;
            this.Eg = this.Gg = this.kh = null;
            this.ii = [];
            var d = a.get("shouldFocus");
            this.Ig = PPa(b, d);
            const e = b.__gm;
            (d = b instanceof _.fl) && c ? c.then(h => {
                this.isOpen && (this.kh = h, this.Eg = new _.TK(k => {
                    this.Gg = new _.ZA(b, h, k, () => {});
                    h.Ai(this.Gg);
                    return this.Gg
                }), this.Eg.bindTo("latLngPosition", a, "position"), XPa(this))
            }) : (this.Eg = new _.TK, this.Eg.bindTo("latLngPosition", a, "position"), this.Eg.bindTo("center", e, "projectionCenterQ"), this.Eg.bindTo("zoom", e), this.Eg.bindTo("offset",
                e), this.Eg.bindTo("projection", b), this.Eg.bindTo("focus", b, "position"), XPa(this));
            this.Jg = d ? AO(a) ? "Ia" : "Id" : null;
            this.Kg = d ? AO(a) ? 148284 : 148285 : null;
            const f = new _.UK(["scale"], "visible", h => h == null || h >= .3);
            this.Eg && f.bindTo("scale", this.Eg);
            const g = this.Ig;
            g.set("logAsInternal", AO(a));
            g.bindTo("ariaLabel", a);
            g.bindTo("zIndex", a);
            g.bindTo("layoutPixelBounds", e, "pixelBounds");
            g.bindTo("disableAutoPan", a);
            g.bindTo("pendingFocus", a);
            g.bindTo("maxWidth", a);
            g.bindTo("minWidth", a);
            g.bindTo("content", a);
            g.bindTo("headerContent",
                a);
            g.bindTo("headerDisabled", a);
            g.bindTo("pixelOffset", a);
            g.bindTo("visible", f);
            this.Fg = new _.tn(() => {
                if (b instanceof _.fl)
                    if (this.kh) {
                        var h = a.get("position");
                        h && _.Zha(b, this.kh, new _.zl(h), TPa(g))
                    } else c.then(() => {
                        this.Fg.start()
                    });
                else(h = g.get("pixelBounds")) ? _.Rk(e, "pantobounds", h) : this.Fg.start()
            }, 150);
            if (d) {
                let h = null;
                this.ii.push(_.Ok(a, "position_changed", () => {
                    const k = a.get("position");
                    !k || a.get("disableAutoPan") || k.equals(h) || (this.Fg.start(), h = k)
                }))
            } else a.get("disableAutoPan") || this.Fg.start();
            g.set("open", !0);
            this.ii.push(_.Dk(g, "domready", () => {
                a.trigger("domready")
            }));
            this.ii.push(_.Dk(g, "visible", () => {
                a.trigger("visible")
            }));
            this.ii.push(_.Dk(g, "closeclick", () => {
                a.close();
                a.trigger("closeclick")
            }));
            this.ii.push(_.Ok(a, "pixelposition_changed", () => {
                WPa(this)
            }));
            this.Jg && _.Ql(b, this.Jg);
            this.Kg && _.Ol(b, this.Kg)
        }
        close() {
            if (this.isOpen) {
                this.isOpen = !1;
                this.model.trigger("close");
                for (var a of this.ii) _.Fk(a);
                this.ii.length = 0;
                this.Fg.stop();
                this.Fg.dispose();
                this.kh && this.Gg && this.kh.um(this.Gg);
                a = this.Ig;
                a.unbindAll();
                a.set("open", !1);
                a.dispose();
                this.Eg && this.Eg.unbindAll()
            }
        }
    };
    _.vk("infowindow", {
        WE: function(a) {
            let b = null;
            _.Ok(a, "map_changed", function d() {
                const e = a.get("map");
                b && (b.XA.Eg.delete(a), b.SI.close(), b = null);
                if (e) {
                    const f = e.__gm;
                    f.get("panes") ? f.get("innerContainer") ? (b = {
                        SI: VPa(a, e, e instanceof _.fl ? f.Fg.then(({
                            kh: g
                        }) => g) : void 0),
                        XA: ZPa(e)
                    }, NPa(b.XA, a)) : _.Nk(f, "innercontainer_changed", d) : _.Nk(f, "panes_changed", d)
                }
            })
        }
    });
});